self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "57a9f986595d58a4907040a6c1692655",
    "url": "/covid-vis/d55c33b848afd88332e6.worker.js"
  },
  {
    "revision": "2ffda2f4be00a3eb7393c7c621af2180",
    "url": "/covid-vis/index.html"
  },
  {
    "revision": "0a01ce8045907c646a75",
    "url": "/covid-vis/static/css/2.3b0d0c3e.chunk.css"
  },
  {
    "revision": "a883a6ac5503c2ac6032",
    "url": "/covid-vis/static/css/main.86a3f0fa.chunk.css"
  },
  {
    "revision": "0a01ce8045907c646a75",
    "url": "/covid-vis/static/js/2.98804527.chunk.js"
  },
  {
    "revision": "a883a6ac5503c2ac6032",
    "url": "/covid-vis/static/js/main.333dc28d.chunk.js"
  },
  {
    "revision": "ae4fa612d6953d968a2f",
    "url": "/covid-vis/static/js/runtime~main.3460a7dd.js"
  },
  {
    "revision": "bb6aa35925514e16f12a233a3b39cae5",
    "url": "/covid-vis/static/media/Inconsolata-Regular.bb6aa359.fnt"
  },
  {
    "revision": "eef1a52f023765d6baf080feba68d5a4",
    "url": "/covid-vis/static/media/Inconsolata-Regular.eef1a52f.png"
  }
]);