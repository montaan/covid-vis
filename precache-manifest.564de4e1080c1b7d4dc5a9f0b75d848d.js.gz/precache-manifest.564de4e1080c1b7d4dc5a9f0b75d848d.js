self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "80fafa0b8fe81a2f2b95fa4aee1952a3",
    "url": "/covid-vis/bd572d15f24caa569fe7.worker.js"
  },
  {
    "revision": "e388ffff9d4520b4b114ab814b6be21c",
    "url": "/covid-vis/index.html"
  },
  {
    "revision": "5b8bd377c5f47e192ede",
    "url": "/covid-vis/static/css/2.67123b20.chunk.css"
  },
  {
    "revision": "a55239b2d28e07874335",
    "url": "/covid-vis/static/css/main.7dae137c.chunk.css"
  },
  {
    "revision": "5b8bd377c5f47e192ede",
    "url": "/covid-vis/static/js/2.f5754639.chunk.js"
  },
  {
    "revision": "a55239b2d28e07874335",
    "url": "/covid-vis/static/js/main.3786569b.chunk.js"
  },
  {
    "revision": "ae4fa612d6953d968a2f",
    "url": "/covid-vis/static/js/runtime~main.3460a7dd.js"
  },
  {
    "revision": "bb6aa35925514e16f12a233a3b39cae5",
    "url": "/covid-vis/static/media/Inconsolata-Regular.bb6aa359.fnt"
  },
  {
    "revision": "eef1a52f023765d6baf080feba68d5a4",
    "url": "/covid-vis/static/media/Inconsolata-Regular.eef1a52f.png"
  }
]);